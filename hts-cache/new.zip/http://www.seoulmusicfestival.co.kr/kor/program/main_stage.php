

<!DOCTYPE html>
<html lang="ko">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0 user-scalable=no">
    <meta name="format-detection" content="telephone=no" />
    <meta property="og:type" content="website">
    <meta property="og:url" content="http://www.seoulmusicfestival.co.kr/">
    <meta property="og:title" content="seoulmusicfestival">
    <meta property="og:image" content="/img/smuf_og.jpg">
    <meta property="og:description" content="아름다운 감성으로 서울 일대를 가득 채울
    뮤직 페스티벌이 개최됩니다.">
    <meta name="description" content="아름다운 감성으로 서울 일대를 가득 채울
    뮤직 페스티벌이 개최됩니다.">
    <meta property="og:site_name" content="seoulmusicfestival">
    <title>2022 SEOUL MUSIC FESTIVAL</title>
    <!-- FONT -->
    <link rel="stylesheet" href="/font/font.css">

     
    
    <!-- CSS -->
    <link rel="stylesheet" href="/utils/css/reset.css">
    <link rel="stylesheet" href="/utils/css/scroll.css">
    <link rel="stylesheet" href="/css/l.css">
    <link rel="stylesheet" href="/css/m.css">
    <link rel="stylesheet" href="/css/sb.css">

    <!-- lib -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@8/swiper-bundle.min.css"/>
    <link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css"/>
    <link href="https://cdn.jsdelivr.net/npm/remixicon@2.5.0/fonts/remixicon.css" rel="stylesheet">

    <!-- plugin -->
    <script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>

    <!-- SCRIPT -->
    <script src="/utils/plugin\jquery.js"></script>	<script type="text/javascript" src="http://www.seoulmusicfestival.co.kr/lib/js/itboard.js"></script>
</head>
<body><header>
    <div class="wrap" max="1400">

        <ul class="logo">
            <li>
                <a href="https://seoulbeautymonth.or.kr/" target="_blank">
                    <img src="/img/logo/logo.png" alt="">
                </a>
            </li>
            <li>
                <a href="https://www.seoul.go.kr/main/index.jsp" target="_blank">
                                        <img src="/img/logo/seoul_logoW.png" alt="">
                                    </a>
            </li>
        </ul>

        
        <ul class="gnb">
            <li>
                <a href="/kor">HOME</a>
            </li>
            <li>
                <a href="/kor/about/outline.php">SMUF 소개</a>
                <ul class="lnb">
                    <li>
                        <a href="/kor/about/outline.php">행사 개요</a>
                    </li>
                    <li>
                        <a href="/kor/about/schedule.php">일정표</a>
                    </li>
                    <li>
                        <a href="/kor/about/map.php">Map</a>
                    </li>
                    <li>
                        <a href="/kor/about/location.php">오시는 길</a>
                    </li>
                </ul>
            </li>

            <li>
                <a href="/kor/lineup/lineup_1013.php">라인업</a>
                <ul class="lnb">
                    <li>
                        <a href="/kor/lineup/lineup_1013.php">라인업</a>
                    </li>
                </ul>
            </li>

            <li>
                <a href="/kor/program/main_stage.php">프로그램</a>
                <ul class="lnb">
                    <li>
                        <a href="/kor/program/main_stage.php">MAIN STAGE</a>
                    </li>
                    <li>
                        <a href="/kor/program/sub_stage.php">SUB STAGE</a>
                    </li>
                    <li>
                        <a href="/kor/program/side_event.php">부대 프로그램</a>
                    </li>
                </ul>
            </li>

            <li>
                <a href="/kor/gallery/gallery.php">갤러리</a>
                <ul class="lnb">
                    <li>
                        <a href="/kor/gallery/gallery.php">SMUF 2022</a>
                    </li>
                    <li>
                        <a href="/kor/gallery/smuf2019.php">SMUF 2019</a>
                    </li>
                </ul>
            </li>

            <li>
                <a href="/kor/community/notice.php">커뮤니티</a>
                <ul class="lnb">
                    <li>
                        <a href="/kor/community/notice.php">공지사항</a>
                    </li>
                    <li>
                        <a href="/kor/community/inquiry.php">문의하기</a>
                    </li>
                    <li>
                        <a href="/kor/community/faq.php">FAQ</a>
                    </li>
                </ul>
            </li>
            
        </ul>

        
        <div class="l_m">

            
            <div class="loc">
                <p>KOR <img src="/img/icon/sh01.png" alt=""></p>
                <ul class="hover">
                    <li><a href="/eng/">ENG</a></li>
                    <li><a href="/kor/">KOR</a></li>
                </ul>
            </div>

            

            <div class="m_m">
                <span></span>
                <span></span>
                <span></span>
            </div>

        </div>

    </div>

    <div class="overBg">
        <div class="wrap" max="1280">
            <img src="/img/header_img.png" alt="">
        </div>
    </div>

    <div class="mobHeader">
                    <ul class="depth1">
                <li>
                    <a href="/kor">HOME</a>
                </li>
                <li>
                    <p><a href="/kor/about/outline.php">SMUF 소개</a> <i class="ri-add-line"></i></>
                    <ul class="depth2">
                        <li>
                            <a href="/kor/about/outline.php">행사 개요</a>
                        </li>
                        <li>
                            <a href="/kor/about/schedule.php">일정표</a>
                        </li>
                        <li>
                            <a href="/kor/about/map.php">Map</a>
                        </li>
                        <li>
                            <a href="/kor/about/location.php">오시는 길</a>
                        </li>
                    </ul>
                </li>
        
                <li>
                    <p><a href="/kor/lineup/lineup_1013.php">라인업</a> <i class="ri-add-line"></i></p>
                    <ul class="depth2">
                        <li>
                            <a href="/kor/lineup/lineup_1013.php">라인업</a>
                        </li>
                    </ul>
                </li>
        
                <li>
                    <p><a href="/kor/program/main_stage.php">프로그램</a> <i class="ri-add-line"></i></p>
                    <ul class="depth2">
                        <li>
                            <a href="/kor/program/main_stage.php">MAIN STAGE</a>
                        </li>
                        <li>
                            <a href="/kor/program/sub_stage.php">SUB STAGE</a>
                        </li>
                        <li>
                            <a href="/kor/program/side_event.php">부대 프로그램</a>
                        </li>
                    </ul>
                </li>
        
                <li>
                    <p><a href="/kor/gallery/gallery.php">갤러리</a> <i class="ri-add-line"></i></p>
                    <ul class="depth2">
                        <li>
                            <a href="/kor/gallery/gallery.php">SMUF 2022</a>
                        </li>
                        <li>
                            <a href="/kor/gallery/smuf2019.php">SMUF 2019</a>
                        </li>
                    </ul>
                </li>
        
                <li>
                    <p><a href="/kor/community/notice.php">커뮤니티</a> <i class="ri-add-line"></i></p>
                    <ul class="depth2"> 
                        <li>
                            <a href="/kor/community/notice.php">공지사항</a>
                        </li>
                        <li>
                            <a href="/kor/community/inquiry.php">문의하기</a>
                        </li>
                        <li>
                            <a href="/kor/community/faq.php">FAQ</a>
                        </li>
                    </ul>
                </li>
        
            </ul>
            </div>

</header>

<script src="/js/hea.js"></script>
<script>hE.init();</script>
<div class="__sv pro"></div>

<main class="_program main_stage _sub">

    <div class="__subw">
        <div class="wave" style="background-image: url(/img/w_wave_148.png);"></div>
    </div>

    <div class="wrap" max="1280">

        <div class="__tp">
            <div class="bx">
                <div class="bef"></div>
                <ul>
                    <li class="on">
                        <a href="./main_stage.php">MAIN STAGE</a>
                    </li>
                    <li>
                        <a href="./sub_stage.php">SUB STAGE</a>
                    </li>
                    <li>
                        <a href="./side_event.php">부대 프로그램</a>
                    </li>
                </ul>
            </div>
        </div>
        
    </div>

        <div class="swiper main_slide">

            <div class="btnlist">
                <button class="prev"></button>
                <button class="next"></button>
            </div>

            <div class="swiper-wrapper">
                <div class="swiper-slide">

                    <div class="wrap" max="1280">

                        <div class="tbx">
                            <h2 class="tit">메인 공연</h2>

                            <div class="bx">
                                <h2 class="line_text">모두의 취향을 아우르는 다양한 음악과 함께 즐기는 서울뮤직페스티벌 메인 공연</h2>
                                <dl>
                                    <dt>일시 : 2022년 10월 13일(목) ~ 16일(일) 19:00 / 장소 : 잔디마당</dt>
                                    <dd>
                                        ※ 메인 공연은 ‘메인 스테이지’ 티켓 예매자만 현장 관람이 가능합니다.<br>
                                        ※ 유튜브 ‘서울시’, ‘THE K-POP’ 채널에서 라이브 스트리밍 진행
                                    </dd>
                                </dl>
                            </div>

                        </div>

                    </div>

                    <div class="line-1013 lines">

                        <div class="wrap" max="1280">

                            <div class="_t">
                                <img src="/img/sub/lineup/lineup_1013_text.png" alt="">
                            </div>

                            <ul class="uls">
                                <li>
                                    <div class="imbx">
                                        <div class="img" style="background-image: url(/img/sub/lineup/lineup_1013_img02.png);"></div>
                                        <div class="line"></div>
                                    </div>
                                    <h2>소란 (SORAN)</h2>
                                </li>
                
                                <li>
                                    <div class="imbx">
                                        <div class="img" style="background-image: url(/img/sub/lineup/lineup_1013_img04.png);"></div>
                                        <div class="line"></div>
                                    </div>
                                    <h2>조유리</h2>
                                </li>
                                
                                <li>
                                    <div class="imbx">
                                        <div class="img" style="background-image: url(/img/sub/lineup/lineup_1013_img05.png);"></div>
                                        <div class="line"></div>
                                    </div>
                                    <h2>정세운</h2>
                                </li>
                
                                <li>
                                    <div class="imbx">
                                        <div class="img" style="background-image: url(/img/sub/lineup/lineup_1013_img03.png);"></div>
                                        <div class="line"></div>
                                    </div>
                                    <h2>HYNN (박혜원)</h2>
                                </li>
                
                                <li>
                                    <div class="imbx">
                                        <div class="img" style="background-image: url(/img/sub/lineup/lineup_1013_img01.png);"></div>
                                        <div class="line"></div>
                                    </div>
                                    <h2>BE’O</h2>
                                </li>
                
                            </ul>

                        </div>

                        <div class="obj">
                            <div class="obb ob1">
                                <img src="/img/sub/lineup/lineup_1013_obj01.png" alt="" data-aos="zoom-in" data-aos-delay="100" data-aos-anchor=".lineImg">
                            </div>
                            <div class="obb ob2">
                                <img src="/img/sub/lineup/lineup_1013_obj02.png" alt="" data-aos="zoom-in" data-aos-delay="200" data-aos-anchor=".lineImg">
                            </div>
                            <div class="obb ob3">
                                <img src="/img/sub/lineup/lineup_1013_obj03.png" alt="" data-aos="zoom-in" data-aos-delay="300" data-aos-anchor=".lineImg">
                            </div>
                        </div>

                    </div>

                    <div class="line-1014 lines">

                        <div class="wrap" max="1280">

                            <div class="_t">
                                <img src="/img/sub/lineup/lineup_1014_text.png" alt="">
                            </div>

                            <ul class="uls l_1014">
                                <li data-aos="fade-up" data-aos-delay="100" data-aos-anchor=".lineImg">
                                    <div class="imbx">
                                        <div class="img" style="background-image: url(/img/sub/lineup/lineup_1014_img01.png);"></div>
                                        <div class="line"></div>
                                    </div>
                                    <h2>백지영</h2>
                                </li>
                                <li data-aos="fade-up" data-aos-delay="200" data-aos-anchor=".lineImg">
                                    <div class="imbx">
                                        <div class="img" style="background-image: url(/img/sub/lineup/lineup_1014_img02.png);"></div>
                                        <div class="line"></div>
                                    </div>
                                    <h2>이석훈</h2>
                                </li>
                                <li data-aos="fade-up" data-aos-delay="300" data-aos-anchor=".lineImg">
                                    <div class="imbx">
                                        <div class="img" style="background-image: url(/img/sub/lineup/lineup_1014_img03.png);"></div>
                                        <div class="line"></div>
                                    </div>
                                    <h2>김필</h2>
                                </li>
                                <li data-aos="fade-up" data-aos-delay="400" data-aos-anchor=".lineImg">
                                    <div class="imbx">
                                        <div class="img" style="background-image: url(/img/sub/lineup/lineup_1014_img04.png);"></div>
                                        <div class="line"></div>
                                    </div>
                                    <h2>웅산</h2>
                                </li>
                                <li data-aos="fade-up" data-aos-delay="500" data-aos-anchor=".lineImg">
                                    <div class="imbx">
                                        <div class="img" style="background-image: url(/img/sub/lineup/lineup_1014_img05.png);"></div>
                                        <div class="line"></div>
                                    </div>
                                    <h2>쏠</h2>
                                </li>
                            </ul>

                        </div>

                        <div class="obj l_1014">
                            <div class="obb ob1">
                                <img src="/img/sub/lineup/lineup_1014_obj01.png" alt="" data-aos="zoom-in" data-aos-delay="100" data-aos-anchor=".lineImg">
                            </div>
                            <div class="obb ob2">
                                <img src="/img/sub/lineup/lineup_1014_obj02.png" alt="" data-aos="zoom-in" data-aos-delay="200" data-aos-anchor=".lineImg">
                            </div>
                            <div class="obb ob3">
                                <img src="/img/sub/lineup/lineup_1014_obj03.png" alt="" data-aos="zoom-in" data-aos-delay="300" data-aos-anchor=".lineImg">
                            </div>
                        </div>

                    </div>

                    <div class="line-1015 lines">

                        <div class="wrap" max="1280">

                            <div class="_t">
                                <img src="/img/sub/lineup/lineup_1015_text.png" alt="">
                            </div>

                            <ul class="uls l_1015">
                                <li data-aos="fade-up" data-aos-delay="100" data-aos-anchor=".lineImg">
                                    <div class="imbx">
                                        <div class="img" style="background-image: url(/img/sub/lineup/lineup_1015_img01.png);"></div>
                                        <div class="line"></div>
                                    </div>
                                    <h2>다이나믹 듀오</h2>
                                </li>
                                <li data-aos="fade-up" data-aos-delay="200" data-aos-anchor=".lineImg">
                                    <div class="imbx">
                                        <div class="img" style="background-image: url(/img/sub/lineup/lineup_1015_img02.png);"></div>
                                        <div class="line"></div>
                                    </div>
                                    <h2>JEONG HONG IL BAND</h2>
                                </li>
                                <li data-aos="fade-up" data-aos-delay="300" data-aos-anchor=".lineImg">
                                    <div class="imbx">
                                        <div class="img" style="background-image: url(/img/sub/lineup/lineup_1015_img03.png);"></div>
                                        <div class="line"></div>
                                    </div>
                                    <h2>N.Flying (엔플라잉)</h2>
                                </li>
                                <li data-aos="fade-up" data-aos-delay="400" data-aos-anchor=".lineImg">
                                    <div class="imbx">
                                        <div class="img" style="background-image: url(/img/sub/lineup/lineup_1015_img04.png);"></div>
                                        <div class="line"></div>
                                    </div>
                                    <h2>미란이</h2>
                                </li>
                                <li data-aos="fade-up" data-aos-delay="500" data-aos-anchor=".lineImg">
                                    <div class="imbx">
                                        <div class="img" style="background-image: url(/img/sub/lineup/lineup_1015_img05.png);"></div>
                                        <div class="line"></div>
                                    </div>
                                    <h2>엑스디너리 히어로즈</h2>
                                </li>
                            </ul>

                        </div>

                        <div class="obj l_1015">
                            <div class="obb ob1">
                                <img src="/img/sub/lineup/lineup_1015_obj01.png" alt="" data-aos="zoom-in" data-aos-delay="100" data-aos-anchor=".lineImg">
                            </div>
                            <div class="obb ob2">
                                <img src="/img/sub/lineup/lineup_1015_obj02.png" alt="" data-aos="zoom-in" data-aos-delay="200" data-aos-anchor=".lineImg">
                            </div>
                            <div class="obb ob3">
                                <img src="/img/sub/lineup/lineup_1015_obj03.png" alt="" data-aos="zoom-in" data-aos-delay="300" data-aos-anchor=".lineImg">
                            </div>
                        </div>

                    </div>

                    <div class="line-1016 lines">

                        <div class="wrap" max="1280">

                            <div class="_t">
                                <img src="/img/sub/lineup/lineup_1016_text.png" alt="">
                            </div>

                            <ul class="uls l_1016">
                                <li data-aos="fade-up" data-aos-delay="100" data-aos-anchor=".lineImg">
                                    <div class="imbx">
                                        <div class="img" style="background-image: url(/img/sub/lineup/lineup_1016_img01.png);"></div>
                                        <div class="line"></div>
                                    </div>
                                    <h2>거미</h2>
                                </li>
                                <li data-aos="fade-up" data-aos-delay="200" data-aos-anchor=".lineImg">
                                    <div class="imbx">
                                        <div class="img" style="background-image: url(/img/sub/lineup/lineup_1016_img02.png);"></div>
                                        <div class="line"></div>
                                    </div>
                                    <h2>김재환</h2>
                                </li>
                                <li data-aos="fade-up" data-aos-delay="300" data-aos-anchor=".lineImg">
                                    <div class="imbx">
                                        <div class="img" style="background-image: url(/img/sub/lineup/lineup_1016_img03.png);"></div>
                                        <div class="line"></div>
                                    </div>
                                    <h2>루시</h2>
                                </li>
                                <li data-aos="fade-up" data-aos-delay="400" data-aos-anchor=".lineImg">
                                    <div class="imbx">
                                        <div class="img" style="background-image: url(/img/sub/lineup/lineup_1016_img04.png);"></div>
                                        <div class="line"></div>
                                    </div>
                                    <h2>에일리 (Ailee)</h2>
                                </li>
                                <li data-aos="fade-up" data-aos-delay="500" data-aos-anchor=".lineImg">
                                    <div class="imbx">
                                        <div class="img" style="background-image: url(/img/sub/lineup/lineup_1016_img05.png);"></div>
                                        <div class="line"></div>
                                    </div>
                                    <h2>하현상</h2>
                                </li>
                            </ul>

                        </div>

                        <div class="obj l_1016">
                            <div class="obb ob1">
                                <img src="/img/sub/lineup/lineup_1016_obj01.png" alt="" data-aos="zoom-in" data-aos-delay="100" data-aos-anchor=".lineImg">
                            </div>
                            <div class="obb ob2">
                                <img src="/img/sub/lineup/lineup_1016_obj02.png" alt="" data-aos="zoom-in" data-aos-delay="200" data-aos-anchor=".lineImg">
                            </div>
                            <div class="obb ob3">
                                <img src="/img/sub/lineup/lineup_1016_obj03.png" alt="" data-aos="zoom-in" data-aos-delay="300" data-aos-anchor=".lineImg">
                            </div>
                        </div>

                    </div>

                </div>
                <div class="swiper-slide">
                    
                    <div class="wrap" max="1280">

                        <div class="tbx">

                            <h2 class="tit">SMUF Talk</h2>

                            <div class="bx">
                                <h2 class="line_text">K-Music과 K-Beauty를 이야기하는 토크 콘서트</h2>
                                <dl>
                                    <dt>일시 : 2022년 10월 13일(목), 14일(금), 16일(일) 18:00 / 장소 : 잔디마당</dt>
                                    <dd>
                                        ※ SMUF Talk는 ‘메인 스테이지’ 티켓 예매자만 현장 관람이 가능합니다.<br>
                                        ※ 유튜브 ‘서울시’, ‘THE K-POP’ 채널에서 라이브 스트리밍 진행
                                    </dd>
                                </dl>
                            </div>

                        </div>

                        <ul class="tap-ul">
                            <li>10/13(목)
                                <div class="obj-img">
                                    <img src="/img/sub/program/main_stage_obj02.png" alt="">
                                </div>
                            </li>
                            <li>10/14(금)</li>
                            <li>10/16(일)</li>
                        </ul>

                        <div class="coming">
                            준비중입니다.

                            <div class="obj-img">
                                <img src="/img/sub/program/main_stage_obj03.png" alt="">
                            </div>

                        </div>


                    </div>

                </div>
                <div class="swiper-slide">

                    <div class="wrap" max="1280">

                        <div class="tbx">

                            <h2 class="tit">K-POP 커버댄스 페스티벌</h2>

                            <div class="bx">
                                <h2 class="line_text">K-POP을 통한 매력적인 한국 문화와의 글로벌 커뮤니케이션 스테이지</h2>
                                <dl>
                                    <dt>일시 : 2022년 10월 15일(토) 17:00 / 장소 : 잔디마당</dt>
                                    <dd>
                                        ※ K-POP 커버댄스 페스티벌은 ‘메인 스테이지’ 티켓 예매자만 현장 관람이 가능합니다.<br>
                                        <!-- ※ 유튜브 ‘서울시’, ‘THE K-POP’ 채널에서 라이브 스트리밍 진행 -->
                                    </dd>
                                </dl>
                            </div>

                        </div>

                        <div class="coming color2">
                            준비중입니다.

                            <div class="obj-img">
                                <img src="/img/sub/program/main_stage_obj06.png" alt="">
                            </div>

                        </div>


                    </div>

                </div>
            </div>
        </div>

</main>

<script src="/js/tap.js"></script>
<script src="/js/subV.js"></script>
<script src="https://cdn.jsdelivr.net/npm/swiper@8/swiper-bundle.min.js"></script>
<script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>

<script>
    subV('프로그램','MAIN STAGE');

    new Swiper('.main_slide',{
        loop : true,
        autoHeight : true,
        navigation: {
            nextEl: '._program .main_slide .btnlist .next',
            prevEl: '._program .main_slide .btnlist .prev',
        },
    });

</script>


<footer>

    <div id="topBtn">
        <img src="/img/icon/topBtnArrow.png" alt="">
        TOP
    </div>

    <div class="w">
        <div class="wave"  style="background-image: url(/img/g_wave.png);"></div>
    </div>
    <div class="wrap" max="1280">

        <div class="sn">
            <div class="fa snn">
                <a href="https://www.facebook.com/seoulmusicfestival" target="_blank">
                    <img src="/img/f_m1.png" alt="">
                </a>
            </div>
            <div class="in snn">
                <a href="https://www.instagram.com/seoulmusicfesta/" target="_blank">
                    <img src="/img/f_m2.png" alt="">
                </a>
            </div>
        </div>

        <div class="c">
            <div class="l">
                <img src="/img/logo/smf_logoW.png" alt="">
            </div>

            <div class="rb">

                                    <div class="add">
                        <span>주소 : 서울시 강남구 도산대로 30길 13-9</span>
                        <span>연락처:070-4170-0944</span>
                        <span>이메일 : seoulmusicfestival@gmail.com</span>
                    </div>
                
                <div class="co">
                    Copyright © 2022 SEOUL MUSIC FESTIVAL. All right reserved.
                </div>

            </div>

        </div>
    </div>

</footer>

<script>
    
    $('#topBtn').click(function(){
        $('html').animate({'scrollTop':"0"},300);
    });

    function topBtnPlus(){
        let yOffset = $(window).scrollTop() + $(window).height();
        let footer, footerWaveHeight;

        if(window.location.pathname.split('/')[2] == "about"){
            footer = $('footer').offset().top;
            footerWaveHeight = $('footer').height();
        }else{
            footer = $('footer .w').offset().top;
            footerWaveHeight = $('footer .w').height();
        }

        if($(window).scrollTop() > 0){
            $('#topBtn').css({
                'opacity':1,
                'visibility':'visible'
            })
        }else{
            $('#topBtn').css({
                'opacity':0,
                'visibility':'hidden'
            })
        }

        if(window.location.pathname.split('/')[2] == "about"){
            if(yOffset >= footer){
                $('#topBtn').css({
                    'transform': `translateY(-100%)`,
                    'bottom':'100%',
                    'position':'absolute'
                });
            }else{
                $('#topBtn').css({
                    'transform': `none`,
                    'bottom':'5%',
                    'position':'fixed'
                });
            }
        }else{
            if(yOffset >= footer){
                $('#topBtn').css({
                    'transform': `translateY(calc(-${footerWaveHeight}px - 30%))`,
                    'bottom':'100%',
                    'position':'absolute'
                });
            }else{
                $('#topBtn').css({
                    'transform': `none`,
                    'bottom':'5%',
                    'position':'fixed'
                });
            }
        }
    }

    $(window).load(function(){
        topBtnPlus();
    });
    window.addEventListener('scroll',topBtnPlus);
    window.addEventListener('resize',topBtnPlus);

</script><script>
    let vh = window.innerHeight * 0.01;
    document.documentElement.style.setProperty('--vh', `${vh}px`);

    window.addEventListener('resize', () => {
        vh = window.innerHeight * 0.01;
        document.documentElement.style.setProperty('--vh', `${vh}px`);
    });

    AOS.init({
        duration : 600
    });
</script>
</body>
</html>