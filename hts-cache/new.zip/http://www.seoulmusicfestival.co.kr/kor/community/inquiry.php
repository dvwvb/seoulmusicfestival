

<!DOCTYPE html>
<html lang="ko">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0 user-scalable=no">
    <meta name="format-detection" content="telephone=no" />
    <meta property="og:type" content="website">
    <meta property="og:url" content="http://www.seoulmusicfestival.co.kr/">
    <meta property="og:title" content="seoulmusicfestival">
    <meta property="og:image" content="/img/smuf_og.jpg">
    <meta property="og:description" content="아름다운 감성으로 서울 일대를 가득 채울
    뮤직 페스티벌이 개최됩니다.">
    <meta name="description" content="아름다운 감성으로 서울 일대를 가득 채울
    뮤직 페스티벌이 개최됩니다.">
    <meta property="og:site_name" content="seoulmusicfestival">
    <title>2022 SEOUL MUSIC FESTIVAL</title>
    <!-- FONT -->
    <link rel="stylesheet" href="/font/font.css">

     
    
    <!-- CSS -->
    <link rel="stylesheet" href="/utils/css/reset.css">
    <link rel="stylesheet" href="/utils/css/scroll.css">
    <link rel="stylesheet" href="/css/l.css">
    <link rel="stylesheet" href="/css/m.css">
    <link rel="stylesheet" href="/css/sb.css">

    <!-- lib -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@8/swiper-bundle.min.css"/>
    <link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css"/>
    <link href="https://cdn.jsdelivr.net/npm/remixicon@2.5.0/fonts/remixicon.css" rel="stylesheet">

    <!-- plugin -->
    <script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>

    <!-- SCRIPT -->
    <script src="/utils/plugin\jquery.js"></script>	<script type="text/javascript" src="http://www.seoulmusicfestival.co.kr/lib/js/itboard.js"></script>
</head>
<body><header>
    <div class="wrap" max="1400">

        <ul class="logo">
            <li>
                <a href="https://seoulbeautymonth.or.kr/" target="_blank">
                    <img src="/img/logo/logo.png" alt="">
                </a>
            </li>
            <li>
                <a href="https://www.seoul.go.kr/main/index.jsp" target="_blank">
                                        <img src="/img/logo/seoul_logoW.png" alt="">
                                    </a>
            </li>
        </ul>

        
        <ul class="gnb">
            <li>
                <a href="/kor">HOME</a>
            </li>
            <li>
                <a href="/kor/about/outline.php">SMUF 소개</a>
                <ul class="lnb">
                    <li>
                        <a href="/kor/about/outline.php">행사 개요</a>
                    </li>
                    <li>
                        <a href="/kor/about/schedule.php">일정표</a>
                    </li>
                    <li>
                        <a href="/kor/about/map.php">Map</a>
                    </li>
                    <li>
                        <a href="/kor/about/location.php">오시는 길</a>
                    </li>
                </ul>
            </li>

            <li>
                <a href="/kor/lineup/lineup_1013.php">라인업</a>
                <ul class="lnb">
                    <li>
                        <a href="/kor/lineup/lineup_1013.php">라인업</a>
                    </li>
                </ul>
            </li>

            <li>
                <a href="/kor/program/main_stage.php">프로그램</a>
                <ul class="lnb">
                    <li>
                        <a href="/kor/program/main_stage.php">MAIN STAGE</a>
                    </li>
                    <li>
                        <a href="/kor/program/sub_stage.php">SUB STAGE</a>
                    </li>
                    <li>
                        <a href="/kor/program/side_event.php">부대 프로그램</a>
                    </li>
                </ul>
            </li>

            <li>
                <a href="/kor/gallery/gallery.php">갤러리</a>
                <ul class="lnb">
                    <li>
                        <a href="/kor/gallery/gallery.php">SMUF 2022</a>
                    </li>
                    <li>
                        <a href="/kor/gallery/smuf2019.php">SMUF 2019</a>
                    </li>
                </ul>
            </li>

            <li>
                <a href="/kor/community/notice.php">커뮤니티</a>
                <ul class="lnb">
                    <li>
                        <a href="/kor/community/notice.php">공지사항</a>
                    </li>
                    <li>
                        <a href="/kor/community/inquiry.php">문의하기</a>
                    </li>
                    <li>
                        <a href="/kor/community/faq.php">FAQ</a>
                    </li>
                </ul>
            </li>
            
        </ul>

        
        <div class="l_m">

            
            <div class="loc">
                <p>KOR <img src="/img/icon/sh01.png" alt=""></p>
                <ul class="hover">
                    <li><a href="/eng/">ENG</a></li>
                    <li><a href="/kor/">KOR</a></li>
                </ul>
            </div>

            

            <div class="m_m">
                <span></span>
                <span></span>
                <span></span>
            </div>

        </div>

    </div>

    <div class="overBg">
        <div class="wrap" max="1280">
            <img src="/img/header_img.png" alt="">
        </div>
    </div>

    <div class="mobHeader">
                    <ul class="depth1">
                <li>
                    <a href="/kor">HOME</a>
                </li>
                <li>
                    <p><a href="/kor/about/outline.php">SMUF 소개</a> <i class="ri-add-line"></i></>
                    <ul class="depth2">
                        <li>
                            <a href="/kor/about/outline.php">행사 개요</a>
                        </li>
                        <li>
                            <a href="/kor/about/schedule.php">일정표</a>
                        </li>
                        <li>
                            <a href="/kor/about/map.php">Map</a>
                        </li>
                        <li>
                            <a href="/kor/about/location.php">오시는 길</a>
                        </li>
                    </ul>
                </li>
        
                <li>
                    <p><a href="/kor/lineup/lineup_1013.php">라인업</a> <i class="ri-add-line"></i></p>
                    <ul class="depth2">
                        <li>
                            <a href="/kor/lineup/lineup_1013.php">라인업</a>
                        </li>
                    </ul>
                </li>
        
                <li>
                    <p><a href="/kor/program/main_stage.php">프로그램</a> <i class="ri-add-line"></i></p>
                    <ul class="depth2">
                        <li>
                            <a href="/kor/program/main_stage.php">MAIN STAGE</a>
                        </li>
                        <li>
                            <a href="/kor/program/sub_stage.php">SUB STAGE</a>
                        </li>
                        <li>
                            <a href="/kor/program/side_event.php">부대 프로그램</a>
                        </li>
                    </ul>
                </li>
        
                <li>
                    <p><a href="/kor/gallery/gallery.php">갤러리</a> <i class="ri-add-line"></i></p>
                    <ul class="depth2">
                        <li>
                            <a href="/kor/gallery/gallery.php">SMUF 2022</a>
                        </li>
                        <li>
                            <a href="/kor/gallery/smuf2019.php">SMUF 2019</a>
                        </li>
                    </ul>
                </li>
        
                <li>
                    <p><a href="/kor/community/notice.php">커뮤니티</a> <i class="ri-add-line"></i></p>
                    <ul class="depth2"> 
                        <li>
                            <a href="/kor/community/notice.php">공지사항</a>
                        </li>
                        <li>
                            <a href="/kor/community/inquiry.php">문의하기</a>
                        </li>
                        <li>
                            <a href="/kor/community/faq.php">FAQ</a>
                        </li>
                    </ul>
                </li>
        
            </ul>
            </div>

</header>

<script src="/js/hea.js"></script>
<script>hE.init();</script>
<div class="__sv community"></div>

<main class="_inquiry _comm _sub">

    <div class="__subw">
        <div class="wave" style="background-image: url(/img/w_wave_148.png);"></div>
    </div>

    <div class="wrap" max="1280">

        <div class="__tp">
            <div class="bx">
                <div class="bef"></div>
                <ul>
                    <li>
                        <a href="./notice.php">공지사항</a>
                    </li>
                    <li class="on">
                        <a href="./inquiry.php">문의하기</a>
                    </li>
                    <li>
                        <a href="./faq.php">FAQ</a>
                    </li>
                </ul>
            </div>
        </div>

        <h2 class="_tit">
            2022 서울뮤직페스티벌에 대해 궁금한 점이 있으신가요?<br>
            아래 양식에 따라 작성 후 제출해주세요!
        </h2>

		            <form name="onlineform" id="onlineform" method="post" autocomplete="off">
			<input type="hidden" name="sending" id="sending" value="N"/>
			<input type="hidden" name="lang" id="lang" value="kr"/>
            <div class="tb">
                <p class="impor"><span>*</span>은 필수입력 사항입니다</p>
                <ul class="inLay">
                    <li>
                        <label for="">
                            이름<span>*</span>
                        </label>
                        <div class="inbx">
                            <input type="text" placeholder="이름을 입력해주세요" name="name" id="name">
                            <p>이름을 입력해주세요</p>
                        </div>
                    </li>
                    <li>
                        <label for="">
                            휴대폰번호<span>*</span>
                        </label>
                        <div class="inbx">
                            <input type="tel" placeholder="'-'없이 숫자만 입력해주세요" name="phone" id="phone" maxlength="11">
                            <p>'-'없이 숫자만 입력해주세요</p>
                        </div>
                    </li>
                    <li>
                        <label for="">
                            이메일<span>*</span>
                        </label>
                        <div class="inbx">
                            <input type="email" placeholder="예) abc123@smuf.com" name="email" id="email">
                            <p>@이하 도메인을 포함한 이메일주소 전체를 입력해주세요</p>
                        </div>
                    </li>
                    <li>
                        <label for="">
                            내용<span>*</span>
                        </label>
                        <div class="tabx">
                            <textarea name="content" id="content" cols="30" rows="10" placeholder="내용을 입력해주세요"></textarea>
                        </div>
                    </li>
                    <li>
                        <label for="">
                            자동입력방지코드
                        </label>
                        <div class="caption">
                             <img src="http://www.seoulmusicfestival.co.kr/lib/plugin/captcha/captcha.php"/>
                            <input type="text" name="captcha" placeholder="보안문자입력" maxlength="4">
                        </div>
                    </li>
                </ul>
            </div>

            <div class="pri">

                <h2 class="tit">개인정보 수집/이용</h2>
                <div class="cont"></div>
                <div class="ck">
                    <input type="checkbox" id="chk" name="agree1" value="Y">
                    <label for="chk">개인정보 수집에 동의합니다</label>
                </div>

                <button type="button" onclick="fnOnline();" id="sendBtn">제출하기</button>
                
            </div>

        </form>

<script>
	var regExp = /([\w-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([\w-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$/;

	function fnOnline() {
		var f = document.onlineform;

		if ($('#sending').val() == "Y") {
			alert('처리중입니다.');
			return false;
		}

		if ($('input:checkbox[name=agree1]:checked').val() != "Y") {
			alert("개인정보 수집에 동의해주세요");
			return false;
		}

		if (f.name.value == "")
		{
			alert("이름을 입력해주세요");
			f.name.focus();
			return false;
		}

		if (f.phone.value == "")
		{
			alert("휴대폰번호를 입력해주세요");
			f.phone.focus();
			return false;
		}

		if (checkEngNumValue($('#phone').val(), "휴대폰번호는 숫자로만 입력해주세요.", 2) == "N")
		{
			$('#phone').focus();
			return false;
		}

		if (f.email.value == "")
		{
			alert("이메일을 입력해주세요");
			f.email.focus();
			return false;
		}

		if (!regExp.test(f.email.value)) {
			alert("이메일 형식에 맞게 입력해주세요");
			f.email.focus();
			return false;
		}

		if (f.content.value == "")
		{
			alert("문의내용을 입력해주세요");
			f.content.focus();
			return false;
		}

		if (f.captcha.value == "")
		{
			alert("보안문자를 입력해주세요");
			f.captcha.focus();
			return false;
		}

		$('#sendBtn').text('처리중..');
		$('#sending').val('Y');

		$.ajax({
			type : 'POST',
			url :  '/itboard/online/online.ajax.php',
			data : $('#onlineform').serialize(),
			dataType : "json",
			success : function(data) {
				if (data.result == 'suc') {
					alert('문의가 완료되었습니다.');
					location.href = "/kor/community/inquiry.php";
				} else if (data.result == 'fail') {
					alert('잠시후 시도해주세요.');
				} else if (data.result == 'fail2') {
					alert('보안문자를 올바르게 입력해주세요.');
				}
			}, error : function (){
				alert("에러가 발생하였습니다.");
			}

		});

		$('#sendBtn').text('제출하기');
		$('#sending').val('N');
	}
</script>
    </div>

</main>

<script src="/js/tap.js"></script>
<script src="/js/pri.js"></script>
<script src="/js/subV.js"></script>

<script>
    subV("커뮤니티",'문의하기');
</script>

<footer>

    <div id="topBtn">
        <img src="/img/icon/topBtnArrow.png" alt="">
        TOP
    </div>

    <div class="w">
        <div class="wave"  style="background-image: url(/img/g_wave.png);"></div>
    </div>
    <div class="wrap" max="1280">

        <div class="sn">
            <div class="fa snn">
                <a href="https://www.facebook.com/seoulmusicfestival" target="_blank">
                    <img src="/img/f_m1.png" alt="">
                </a>
            </div>
            <div class="in snn">
                <a href="https://www.instagram.com/seoulmusicfesta/" target="_blank">
                    <img src="/img/f_m2.png" alt="">
                </a>
            </div>
        </div>

        <div class="c">
            <div class="l">
                <img src="/img/logo/smf_logoW.png" alt="">
            </div>

            <div class="rb">

                                    <div class="add">
                        <span>주소 : 서울시 강남구 도산대로 30길 13-9</span>
                        <span>연락처:070-4170-0944</span>
                        <span>이메일 : seoulmusicfestival@gmail.com</span>
                    </div>
                
                <div class="co">
                    Copyright © 2022 SEOUL MUSIC FESTIVAL. All right reserved.
                </div>

            </div>

        </div>
    </div>

</footer>

<script>
    
    $('#topBtn').click(function(){
        $('html').animate({'scrollTop':"0"},300);
    });

    function topBtnPlus(){
        let yOffset = $(window).scrollTop() + $(window).height();
        let footer, footerWaveHeight;

        if(window.location.pathname.split('/')[2] == "about"){
            footer = $('footer').offset().top;
            footerWaveHeight = $('footer').height();
        }else{
            footer = $('footer .w').offset().top;
            footerWaveHeight = $('footer .w').height();
        }

        if($(window).scrollTop() > 0){
            $('#topBtn').css({
                'opacity':1,
                'visibility':'visible'
            })
        }else{
            $('#topBtn').css({
                'opacity':0,
                'visibility':'hidden'
            })
        }

        if(window.location.pathname.split('/')[2] == "about"){
            if(yOffset >= footer){
                $('#topBtn').css({
                    'transform': `translateY(-100%)`,
                    'bottom':'100%',
                    'position':'absolute'
                });
            }else{
                $('#topBtn').css({
                    'transform': `none`,
                    'bottom':'5%',
                    'position':'fixed'
                });
            }
        }else{
            if(yOffset >= footer){
                $('#topBtn').css({
                    'transform': `translateY(calc(-${footerWaveHeight}px - 30%))`,
                    'bottom':'100%',
                    'position':'absolute'
                });
            }else{
                $('#topBtn').css({
                    'transform': `none`,
                    'bottom':'5%',
                    'position':'fixed'
                });
            }
        }
    }

    $(window).load(function(){
        topBtnPlus();
    });
    window.addEventListener('scroll',topBtnPlus);
    window.addEventListener('resize',topBtnPlus);

</script><script>
    let vh = window.innerHeight * 0.01;
    document.documentElement.style.setProperty('--vh', `${vh}px`);

    window.addEventListener('resize', () => {
        vh = window.innerHeight * 0.01;
        document.documentElement.style.setProperty('--vh', `${vh}px`);
    });

    AOS.init({
        duration : 600
    });
</script>
</body>
</html>