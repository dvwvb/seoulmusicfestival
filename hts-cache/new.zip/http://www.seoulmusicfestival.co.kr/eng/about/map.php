

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0 user-scalable=no">
    <meta name="format-detection" content="telephone=no" />
    <meta property="og:type" content="website">
    <meta property="og:url" content="http://www.seoulmusicfestival.co.kr/">
    <meta property="og:title" content="seoulmusicfestival">
    <meta property="og:image" content="/img/smuf_og.jpg">
    <meta property="og:description" content="아름다운 감성으로 서울 일대를 가득 채울
    뮤직 페스티벌이 개최됩니다.">
    <meta name="description" content="아름다운 감성으로 서울 일대를 가득 채울
    뮤직 페스티벌이 개최됩니다.">
    <meta property="og:site_name" content="seoulmusicfestival">
    <title>2022 SEOUL MUSIC FESTIVAL</title>
    <!-- FONT -->
    <link rel="stylesheet" href="/font/font.css">

        
    <!-- CSS -->
    <link rel="stylesheet" href="/utils/css/reset.css">
    <link rel="stylesheet" href="/utils/css/scroll.css">
    <link rel="stylesheet" href="/css/l.css">
    <link rel="stylesheet" href="/css/m.css">
    <link rel="stylesheet" href="/css/sb.css">

    <!-- lib -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@8/swiper-bundle.min.css"/>
    <link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css"/>
    <link href="https://cdn.jsdelivr.net/npm/remixicon@2.5.0/fonts/remixicon.css" rel="stylesheet">

    <!-- plugin -->
    <script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>

    <!-- SCRIPT -->
    <script src="/utils/plugin\jquery.js"></script>	<script type="text/javascript" src="http://www.seoulmusicfestival.co.kr/lib/js/itboard.js"></script>
</head>
<body><header>
    <div class="wrap" max="1400">

        <ul class="logo">
            <li>
                <a href="https://seoulbeautymonth.or.kr/" target="_blank">
                    <img src="/img/logo/logo.png" alt="">
                </a>
            </li>
            <li>
                <a href="https://www.seoul.go.kr/main/index.jsp" target="_blank">
                     
                    <img width="130" src="/img/logo/seoul_eng_logoC.png" alt="" style="filter:brightness(0) invert(1);">
                                    </a>
            </li>
        </ul>

         

        <ul class="gnb">
            <li>
                <a href="/eng">HOME</a>
            </li>
            <li>
                <a href="/eng/about/outline.php">About SMUF</a>
                <ul class="lnb">
                    <li>
                        <a href="/eng/about/outline.php">Overview</a>
                    </li>
                    <li>
                        <a href="/eng/about/schedule.php">Schedule</a>
                    </li>
                    <li>
                        <a href="/eng/about/map.php">Map</a>
                    </li>
                    <li>
                        <a href="/eng/about/location.php">Location</a>
                    </li>
                </ul>
            </li>

            <li>
                <a href="/eng/lineup/lineup_1013.php">Lineup</a>
                <ul class="lnb">
                    <li>
                        <a href="/eng/lineup/lineup_1013.php">Lineup</a>
                    </li>
                </ul>
            </li>

            <li>
                <a href="/eng/program/main_stage.php">Programs</a>
                <ul class="lnb">
                    <li>
                        <a href="/eng/program/main_stage.php">MAIN STAGE</a>
                    </li>
                    <li>
                        <a href="/eng/program/sub_stage.php">SUB STAGE</a>
                    </li>
                    <li>
                        <a href="/eng/program/side_event.php">SIDE EVENTS</a>
                    </li>
                </ul>
            </li>

            <li>
                <a href="/eng/gallery/gallery.php">Gallery</a>
                <ul class="lnb">
                    <li>
                        <a href="/eng/gallery/gallery.php">SMUF 2022</a>
                    </li>
                    <li>
                        <a href="/eng/gallery/smuf2019.php">SMUF 2019</a>
                    </li>
                </ul>
            </li>

            <li>
                <a href="/eng/community/notice.php">Community</a>
                <ul class="lnb">
                    <li>
                        <a href="/eng/community/notice.php">Announcements</a>
                    </li>
                    <li>
                        <a href="/eng/community/inquiry.php">Q&A</a>
                    </li>
                    <li>
                        <a href="/eng/community/faq.php">FAQ</a>
                    </li>
                </ul>
            </li>
            
        </ul>

        
        <div class="l_m">

            
            <div class="loc">
                <p>ENG <img src="/img/icon/sh01.png" alt=""></p>
                <ul class="hover">
                    <li><a href="/kor/">KOR</a></li>
                    <li><a href="/eng/">ENG</a></li>
                </ul>
            </div>

            

            <div class="m_m">
                <span></span>
                <span></span>
                <span></span>
            </div>

        </div>

    </div>

    <div class="overBg">
        <div class="wrap" max="1280">
            <img src="/img/header_img.png" alt="">
        </div>
    </div>

    <div class="mobHeader">
                    <ul class="depth1">
                <li>
                    <a href="/eng">HOME</a>
                </li>
                <li>
                    <p><a href="/eng/about/outline.php">About SMUF</a> <i class="ri-add-line"></i></>
                    <ul class="depth2">
                        <li>
                            <a href="/eng/about/outline.php">Overview</a>
                        </li>
                        <li>
                            <a href="/eng/about/schedule.php">Schedule</a>
                        </li>
                        <li>
                            <a href="/eng/about/map.php">Map</a>
                        </li>
                        <li>
                            <a href="/eng/about/location.php">Location</a>
                        </li>
                    </ul>
                </li>
        
                <li>
                    <p><a href="/eng/lineup/lineup_1013.php">Lineup</a> <i class="ri-add-line"></i></p>
                    <ul class="depth2">
                        <li>
                            <a href="/eng/lineup/lineup_1013.php">Lineup</a>
                        </li>
                    </ul>
                </li>
        
                <li>
                    <p><a href="/eng/program/main_stage.php">Programs</a> <i class="ri-add-line"></i></p>
                    <ul class="depth2">
                        <li>
                            <a href="/eng/program/main_stage.php">MAIN STAGE</a>
                        </li>
                        <li>
                            <a href="/eng/program/sub_stage.php">SUB STAGE</a>
                        </li>
                        <li>
                            <a href="/eng/program/side_event.php">SIDE EVENTS</a>
                        </li>
                    </ul>
                </li>
        
                <li>
                    <p><a href="/eng/gallery/gallery.php">Gallery</a> <i class="ri-add-line"></i></p>
                    <ul class="depth2">
                        <li>
                            <a href="/eng/gallery/gallery.php">SMUF 2022</a>
                        </li>
                        <li>
                            <a href="/eng/gallery/smuf2019.php">SMUF 2019</a>
                        </li>
                    </ul>
                </li>
        
                <li>
                    <p><a href="/eng/community/notice.php">Community</a> <i class="ri-add-line"></i></p>
                    <ul class="depth2"> 
                        <li>
                            <a href="/eng/community/notice.php">Announcements</a>
                        </li>
                        <li>
                            <a href="/eng/community/inquiry.php">Q&A</a>
                        </li>
                        <li>
                            <a href="/eng/community/faq.php">FAQ</a>
                        </li>
                    </ul>
                </li>
        
            </ul>
            </div>

</header>

<script src="/js/hea.js"></script>
<script>hE.init();</script>
<div class="__sv"></div>

<main class="_location __eng _sub __about">


    <div class="__subw">
        <div class="wave" style="background-image: url(/img/w_wave_148.png);"></div>
    </div>

    <div class="wrap" max="1280">

        <div class="__tp">
            <div class="bx">
                <div class="bef"></div>
                <ul>
                    <li>
                        <a href="./outline.php">Overview</a>
                    </li>
                    <li>
                        <a href="./schedule.php">Schedule</a>
                    </li>
                    <li>
                        <a href="./location.php">Location</a>
                    </li>
                    <li class="on">
                        <a href="./map.php">MAP</a>
                    </li>
                </ul>
            </div>
        </div>

        <div style="max-width: 1000px; margin: 25px auto 0; display: block;">
            <img src="/img/place_eng.jpg" alt="" >
        </div>

    </div>

</main>

<script src="/js/tap.js"></script>
<script src="/js/subV.js"></script>
<script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>

<script>
    subV('About SMUF','Map');
</script>



<footer>

    <div id="topBtn">
        <img src="/img/icon/topBtnArrow.png" alt="">
        TOP
    </div>

    <div class="w">
        <div class="wave"  style="background-image: url(/img/g_wave.png);"></div>
    </div>
    <div class="wrap" max="1280">

        <div class="sn">
            <div class="fa snn">
                <a href="https://www.facebook.com/seoulmusicfestival" target="_blank">
                    <img src="/img/f_m1.png" alt="">
                </a>
            </div>
            <div class="in snn">
                <a href="https://www.instagram.com/seoulmusicfesta/" target="_blank">
                    <img src="/img/f_m2.png" alt="">
                </a>
            </div>
        </div>

        <div class="c">
            <div class="l">
                <img src="/img/logo/smf_logoW.png" alt="">
            </div>

            <div class="rb">

                                    <div class="add">
                        <span>Address : 13-9, Dosan-daero 30-gil, Gangnam-gu, Seoul</span>
                        <span>Tel:070-4170-0944</span>
                        <span>Email : seoulmusicfestival@gmail.com</span>
                    </div>
                
                <div class="co">
                    Copyright © 2022 SEOUL MUSIC FESTIVAL. All right reserved.
                </div>

            </div>

        </div>
    </div>

</footer>

<script>
    
    $('#topBtn').click(function(){
        $('html').animate({'scrollTop':"0"},300);
    });

    function topBtnPlus(){
        let yOffset = $(window).scrollTop() + $(window).height();
        let footer, footerWaveHeight;

        if(window.location.pathname.split('/')[2] == "about"){
            footer = $('footer').offset().top;
            footerWaveHeight = $('footer').height();
        }else{
            footer = $('footer .w').offset().top;
            footerWaveHeight = $('footer .w').height();
        }

        if($(window).scrollTop() > 0){
            $('#topBtn').css({
                'opacity':1,
                'visibility':'visible'
            })
        }else{
            $('#topBtn').css({
                'opacity':0,
                'visibility':'hidden'
            })
        }

        if(window.location.pathname.split('/')[2] == "about"){
            if(yOffset >= footer){
                $('#topBtn').css({
                    'transform': `translateY(-100%)`,
                    'bottom':'100%',
                    'position':'absolute'
                });
            }else{
                $('#topBtn').css({
                    'transform': `none`,
                    'bottom':'5%',
                    'position':'fixed'
                });
            }
        }else{
            if(yOffset >= footer){
                $('#topBtn').css({
                    'transform': `translateY(calc(-${footerWaveHeight}px - 30%))`,
                    'bottom':'100%',
                    'position':'absolute'
                });
            }else{
                $('#topBtn').css({
                    'transform': `none`,
                    'bottom':'5%',
                    'position':'fixed'
                });
            }
        }
    }

    $(window).load(function(){
        topBtnPlus();
    });
    window.addEventListener('scroll',topBtnPlus);
    window.addEventListener('resize',topBtnPlus);

</script><script>
    let vh = window.innerHeight * 0.01;
    document.documentElement.style.setProperty('--vh', `${vh}px`);

    window.addEventListener('resize', () => {
        vh = window.innerHeight * 0.01;
        document.documentElement.style.setProperty('--vh', `${vh}px`);
    });

    AOS.init({
        duration : 600
    });
</script>
</body>
</html>